
A sacred `RunObserver` which uses `visdom` to plot logged metrics and image artifacts. Supports creation
of dynamically updating plots with different sets of metrics easily.


